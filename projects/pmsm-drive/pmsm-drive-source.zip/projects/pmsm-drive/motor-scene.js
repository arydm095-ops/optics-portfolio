(function(){'use strict';let renderer,scene,camera,controls,rotor,load,frame,ready=false,last;
function init(){const host=document.getElementById('motor-scene');if(!window.THREE){host.textContent='三维视图未加载，控制曲线仍可查看。';return;}
 try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));host.appendChild(renderer.domElement);scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(35,1,.1,100);camera.position.set(5,3.3,5.8);controls=new THREE.OrbitControls(camera,renderer.domElement);controls.target.set(.45,.1,0);controls.enableDamping=false;controls.addEventListener('change',draw);scene.add(new THREE.HemisphereLight(0xeef7ff,0x59737e,1.3));const light=new THREE.DirectionalLight(0xffffff,1);light.position.set(3,5,4);scene.add(light);
 const steel=new THREE.MeshStandardMaterial({color:0xb7c7d1,metalness:.58,roughness:.42}),dark=new THREE.MeshStandardMaterial({color:0x385362,metalness:.5,roughness:.5});
 function box(x,y,z,material,pos){const m=new THREE.Mesh(new THREE.BoxGeometry(x,y,z),material);m.position.set(...pos);scene.add(m);return m;}
 function cylinder(radius,length,material,x){const m=new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,length,64),material);m.rotation.z=Math.PI/2;m.position.x=x;scene.add(m);return m;}
 box(5,.13,2.15,dark,[.55,-1.14,0]);box(1.3,.35,1.45,steel,[-.65,-.93,0]);box(.85,.5,.9,steel,[2.3,-.9,0]);
 const housing=new THREE.Mesh(new THREE.TorusGeometry(.82,.15,16,64),steel);housing.rotation.y=Math.PI/2;housing.position.x=-.8;scene.add(housing);
 const housing2=housing.clone();housing2.position.x=-.1;scene.add(housing2);
 const shell=new THREE.Mesh(new THREE.CylinderGeometry(.92,.92,.72,64,1,true,0,Math.PI*1.45),new THREE.MeshStandardMaterial({color:0x9fb3c1,metalness:.3,roughness:.5,transparent:true,opacity:.32,side:THREE.DoubleSide}));shell.rotation.z=Math.PI/2;shell.position.x=-.45;scene.add(shell);
 for(let k=0;k<12;k++){let a=k*Math.PI/6;const tooth=new THREE.Mesh(new THREE.BoxGeometry(.65,.21,.17),dark);tooth.position.set(-.45,.72*Math.cos(a),.72*Math.sin(a));tooth.rotation.x=a;scene.add(tooth);const copper=new THREE.Mesh(new THREE.BoxGeometry(.48,.18,.21),new THREE.MeshStandardMaterial({color:0xbd8054,metalness:.65,roughness:.48}));copper.position.set(-.45,.89*Math.cos(a),.89*Math.sin(a));copper.rotation.x=a;scene.add(copper);}
 rotor=new THREE.Group();rotor.position.x=-.45;scene.add(rotor);const core=new THREE.Mesh(new THREE.CylinderGeometry(.48,.48,.75,48),steel);core.rotation.z=Math.PI/2;rotor.add(core);
 for(let k=0;k<8;k++){const a=k*Math.PI/4,m=new THREE.Mesh(new THREE.BoxGeometry(.65,.095,.23),new THREE.MeshStandardMaterial({color:k%2?0xc96656:0x218795,metalness:.38,roughness:.5}));m.position.set(0,.5*Math.cos(a),.5*Math.sin(a));m.rotation.x=a;rotor.add(m);}
 cylinder(.14,3.5,steel,.65);const collar=cylinder(.23,.23,dark,.65);collar.position.y=0;
 load=new THREE.Group();load.position.x=2.15;scene.add(load);const disc=new THREE.Mesh(new THREE.CylinderGeometry(.65,.65,.28,64),steel);disc.rotation.z=Math.PI/2;load.add(disc);for(let k=0;k<6;k++){const a=k*Math.PI/3,m=new THREE.Mesh(new THREE.BoxGeometry(.31,.12,.15),dark);m.position.set(.17,.4*Math.cos(a),.4*Math.sin(a));m.rotation.x=a;load.add(m);}
 const grid=new THREE.GridHelper(7,20,0xb2c5ce,0xd9e3e8);grid.position.y=-1.23;scene.add(grid);ready=true;new ResizeObserver(resize).observe(host);resize();
 }catch(e){host.textContent='当前浏览器不支持三维渲染。';}}
function resize(){if(!ready)return;const h=document.getElementById('motor-scene');renderer.setSize(h.clientWidth,h.clientHeight,false);camera.aspect=h.clientWidth/h.clientHeight;camera.updateProjectionMatrix();draw();}
function draw(){if(ready)renderer.render(scene,camera);}
function update(state){last=state;if(!ready)return;const angle=state.position*Math.PI/180;rotor.rotation.x=angle;load.rotation.x=angle;draw();}
window.DriveMotorScene={init,update,resize};})();
