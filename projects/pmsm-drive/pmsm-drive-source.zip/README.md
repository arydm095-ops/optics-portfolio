# PMSM驱动控制与软件验证

启动网页：在本目录运行 `python -m http.server 8000`，打开 http://localhost:8000/ 。

编译与回归：进入 `projects/pmsm-drive`，运行 `python build.py --gcc path/to/gcc --clang path/to/clang` 和 `node tests.cjs`。

MATLAB/Simulink：进入 `projects/pmsm-drive/matlab`，运行 `build_mil`。

全部说明见 `projects/pmsm-drive/README.md`。
